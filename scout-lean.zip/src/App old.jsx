import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { onAuthStateChanged } from 'firebase/auth';
import { auth, db } from './firebase/config';
import { doc, getDoc } from 'firebase/firestore';

// Pages
import Login from './pages/Login';
import Signup from './pages/Signup';
import Dashboard from './pages/Dashboard';
import DashboardV2 from './pages/Dashboard-v2';
import Prospects from './pages/Prospects';
import Questionnaire from './pages/Questionnaire';

// Components
import ScoutQuestionnaire from './components/ScoutQuestionnaire';
import ICPValidationPage from './components/ICPValidationPage';
import LaunchSequence from './components/LaunchSequence';

function App() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [userData, setUserData] = useState(null);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      if (currentUser) {
        // Fetch user data from Firestore
        try {
          const userDoc = await getDoc(doc(db, 'users', currentUser.uid));
          if (userDoc.exists()) {
            const data = userDoc.data();
            setUserData(data);
            setUser({
              id: currentUser.uid,
              email: currentUser.email,
              ...data
            });
          } else {
            setUser({
              id: currentUser.uid,
              email: currentUser.email
            });
          }
        } catch (error) {
          console.error('Error fetching user data:', error);
          setUser({
            id: currentUser.uid,
            email: currentUser.email
          });
        }
      } else {
        setUser(null);
        setUserData(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // Protected Route Component
  const ProtectedRoute = ({ children }) => {
    if (loading) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-black">
          <p className="text-cyan-400 text-xl font-mono">Loading...</p>
        </div>
      );
    }

    if (!user) {
      return <Navigate to="/login" />;
    }

    return children;
  };

  // Smart redirect after login
  const SmartRedirect = () => {
    if (loading) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-black">
          <p className="text-cyan-400 text-xl font-mono">Loading...</p>
        </div>
      );
    }

    if (!user) {
      return <Navigate to="/login" />;
    }

    // If user has completed Scout questionnaire, go to dashboard-v2
    if (userData?.scoutCompleted) {
      return <Navigate to="/dashboard-v2" />;
    }

    // If user has scoutData but hasn't completed, go back to scout questionnaire
    if (userData?.scoutData) {
      return <Navigate to="/scout-questionnaire" />;
    }

    // New users go to Scout questionnaire
    return <Navigate to="/scout-questionnaire" />;
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-black">
        <p className="text-cyan-400 text-xl font-mono">Loading...</p>
      </div>
    );
  }

  return (
    <BrowserRouter>
      <Routes>
        {/* Public Routes */}
        <Route path="/login" element={!user ? <Login /> : <Navigate to="/" />} />
        <Route path="/signup" element={!user ? <Signup /> : <Navigate to="/" />} />

        {/* Protected Routes - Scout Flow */}
        <Route
          path="/scout-questionnaire"
          element={
            <ProtectedRoute>
              <ScoutQuestionnaire />
            </ProtectedRoute>
          }
        />
        <Route
          path="/icp-validation"
          element={
            <ProtectedRoute>
              <ICPValidationPage />
            </ProtectedRoute>
          }
        />
        <Route
          path="/launch-sequence"
          element={
            <ProtectedRoute>
              <LaunchSequence />
            </ProtectedRoute>
          }
        />

        {/* Protected Routes - Dashboards */}
        <Route
          path="/dashboard-v2"
          element={
            <ProtectedRoute>
              <DashboardV2 />
            </ProtectedRoute>
          }
        />
        <Route
          path="/dashboard"
          element={
            <ProtectedRoute>
              <Dashboard />
            </ProtectedRoute>
          }
        />

        {/* Protected Routes - Old Flow (keep for backwards compatibility) */}
        <Route
          path="/questionnaire"
          element={
            <ProtectedRoute>
              <Questionnaire />
            </ProtectedRoute>
          }
        />
        <Route
          path="/prospects"
          element={
            <ProtectedRoute>
              <Prospects />
            </ProtectedRoute>
          }
        />

        {/* Default Route - Smart Redirect */}
        <Route path="/" element={<SmartRedirect />} />

        {/* 404 */}
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
