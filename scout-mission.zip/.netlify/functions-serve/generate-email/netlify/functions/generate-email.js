var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/generate-email.js
var generate_email_exports = {};
__export(generate_email_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(generate_email_exports);
var handler = async (event, context) => {
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      body: JSON.stringify({ error: "Method not allowed" })
    };
  }
  try {
    const { lead, icpData } = JSON.parse(event.body);
    if (!lead || !icpData) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: "Lead and ICP data are required" })
      };
    }
    const prompt = `Generate a personalized cold email for this lead:

Lead Info:
- Name: ${lead.name}
- Title: ${lead.title}
- Company: ${lead.company}

ICP Context:
- Industry: ${icpData.industry}
- Pain Points: ${icpData.painPoints}
- Value Proposition: ${icpData.valueProposition}

Create a short, personalized cold email (3-4 sentences max) that:
1. References their role/company
2. Mentions a specific pain point they likely face
3. Suggests how our solution helps
4. Includes a soft CTA

Keep it casual, concise, and conversational. Don't sound salesy.`;
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01"
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 500,
        messages: [{
          role: "user",
          content: prompt
        }]
      })
    });
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(`Claude API error: ${errorData.error?.message || "Unknown error"}`);
    }
    const data = await response.json();
    const emailContent = data.content[0].text;
    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
      },
      body: JSON.stringify({
        email: emailContent
      })
    };
  } catch (error) {
    console.error("Error generating email:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({
        error: "Failed to generate email",
        message: error.message
      })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
//# sourceMappingURL=generate-email.js.map
