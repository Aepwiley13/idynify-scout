// netlify/functions/generate-leads.js
function calculateLeadScore(lead, scoutData, icpBrief) {
  let score = 0;
  const breakdown = {
    title: 0,
    industry: 0,
    size: 0,
    location: 0,
    notAvoid: 0,
    dataQuality: 0
  };
  const matchDetails = [];
  const targetTitles = scoutData.jobTitles || [];
  const leadTitle = (lead.title || "").toLowerCase();
  let titleMatch = false;
  for (const targetTitle of targetTitles) {
    const target = targetTitle.toLowerCase();
    if (leadTitle.includes(target) || target.includes(leadTitle)) {
      if (leadTitle === target) {
        breakdown.title = 25;
        matchDetails.push(`\u2713 Exact title match (${lead.title})`);
      } else {
        breakdown.title = 20;
        matchDetails.push(`\u2713 Close title match (${lead.title})`);
      }
      titleMatch = true;
      break;
    }
  }
  if (!titleMatch && leadTitle.length > 0) {
    const keywords = ["vp", "vice president", "director", "head", "chief", "manager", "ceo", "cfo", "cto", "president", "owner", "founder"];
    if (keywords.some((kw) => leadTitle.includes(kw))) {
      breakdown.title = 12;
      matchDetails.push(`\u26A0 Related title (${lead.title})`);
    }
  }
  const targetIndustries = scoutData.industries || [];
  const leadIndustry = (lead.organization?.industry || "").toLowerCase();
  let industryMatch = false;
  for (const targetIndustry of targetIndustries) {
    const target = targetIndustry.toLowerCase();
    if (leadIndustry.includes(target) || target.includes(leadIndustry)) {
      breakdown.industry = 20;
      matchDetails.push(`\u2713 Perfect industry (${lead.organization?.industry || "N/A"})`);
      industryMatch = true;
      break;
    }
  }
  if (!industryMatch && leadIndustry.length > 0) {
    breakdown.industry = 8;
    matchDetails.push(`\u26A0 Different industry (${lead.organization?.industry || "N/A"})`);
  }
  const leadEmployees = lead.organization?.estimated_num_employees || 0;
  const targetSizes = scoutData.companySizes || [];
  let sizeMatch = false;
  for (const sizeRange of targetSizes) {
    const match = sizeRange.match(/(\d+)-(\d+)/);
    if (match) {
      const min = parseInt(match[1]);
      const max = parseInt(match[2]);
      if (leadEmployees >= min && leadEmployees <= max) {
        breakdown.size = 20;
        matchDetails.push(`\u2713 Ideal company size (${leadEmployees} employees)`);
        sizeMatch = true;
        break;
      }
    } else if (sizeRange.includes("1000+") && leadEmployees >= 1e3) {
      breakdown.size = 20;
      matchDetails.push(`\u2713 Ideal company size (${leadEmployees} employees)`);
      sizeMatch = true;
      break;
    }
  }
  if (!sizeMatch && leadEmployees > 0) {
    breakdown.size = 10;
    matchDetails.push(`\u26A0 Size outside target range (${leadEmployees} employees)`);
  }
  const personLocation = {
    city: (lead.city || "").toLowerCase(),
    state: (lead.state || "").toLowerCase(),
    country: (lead.country || "").toLowerCase()
  };
  if (scoutData.locationScope?.includes("All US") || scoutData.locationScope?.includes("Remote")) {
    breakdown.location = 15;
    matchDetails.push(`\u2713 Location: ${scoutData.locationScope.join(", ")}`);
  } else {
    let locationMatched = false;
    if (scoutData.targetStates && scoutData.targetStates.length > 0) {
      for (const targetState of scoutData.targetStates) {
        if (personLocation.state.includes(targetState.toLowerCase()) || targetState.toLowerCase().includes(personLocation.state)) {
          breakdown.location = 15;
          matchDetails.push(`\u2713 Target state (${lead.state})`);
          locationMatched = true;
          break;
        }
      }
    }
    if (!locationMatched && scoutData.targetCities && scoutData.targetCities.length > 0) {
      for (const targetCity of scoutData.targetCities) {
        const cityName = targetCity.toLowerCase().replace(" metro", "").replace(" area", "");
        if (personLocation.city.includes(cityName) || cityName.includes(personLocation.city)) {
          breakdown.location = 15;
          matchDetails.push(`\u2713 Target metro (${lead.city})`);
          locationMatched = true;
          break;
        }
      }
    }
    if (!locationMatched && personLocation.country.includes("united states")) {
      breakdown.location = 5;
      matchDetails.push(`\u26A0 US location but not target area (${lead.state || lead.city})`);
    } else if (!locationMatched) {
      matchDetails.push(`\u2717 Outside target locations (${lead.state || lead.country || "Unknown"})`);
    }
  }
  const avoidList = (scoutData.avoidList || "").toLowerCase();
  const companyName = (lead.organization?.name || "").toLowerCase();
  let isAvoided = false;
  if (avoidList && avoidList.split(",").some((avoid) => companyName.includes(avoid.trim()))) {
    isAvoided = true;
    matchDetails.push("\u2717 Company in avoid list");
  }
  if (avoidList.includes("enterprise") && leadEmployees > 1e3) {
    isAvoided = true;
    matchDetails.push("\u26A0 Large enterprise (in avoid criteria)");
  }
  if (avoidList.includes("b2c") && leadIndustry.includes("consumer")) {
    isAvoided = true;
    matchDetails.push("\u26A0 B2C company (in avoid criteria)");
  }
  if (!isAvoided) {
    breakdown.notAvoid = 10;
    matchDetails.push("\u2713 Not in avoid list");
  }
  let dataScore = 0;
  if (lead.email) {
    dataScore += 5;
    matchDetails.push("\u2713 Email available");
  }
  if (lead.linkedin_url) {
    dataScore += 3;
    matchDetails.push("\u2713 LinkedIn profile");
  }
  if (lead.phone_numbers && lead.phone_numbers.length > 0) {
    dataScore += 2;
    matchDetails.push("\u2713 Phone number");
  }
  breakdown.dataQuality = Math.min(dataScore, 10);
  score = breakdown.title + breakdown.industry + breakdown.size + breakdown.location + breakdown.notAvoid + breakdown.dataQuality;
  return { score, breakdown, matchDetails };
}
function buildLocationArray(scoutData) {
  const locations = [];
  if (scoutData.locationScope?.includes("All US")) {
    return ["United States"];
  }
  if (scoutData.targetStates && scoutData.targetStates.length > 0) {
    locations.push(...scoutData.targetStates.map((state) => `${state}, United States`));
  }
  if (scoutData.targetCities && scoutData.targetCities.length > 0) {
    locations.push(...scoutData.targetCities.map((city) => {
      const cityName = city.replace(" Metro", "").replace(" Area", "").replace(" Bay", "");
      return cityName;
    }));
  }
  return locations.length > 0 ? locations : ["United States"];
}
exports.handler = async (event, context) => {
  console.log("\u{1F3AF} Generate Leads - Enhanced Scoring with ICP Brief");
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "POST, OPTIONS"
      },
      body: ""
    };
  }
  try {
    let requestBody;
    try {
      requestBody = JSON.parse(event.body);
    } catch (parseError) {
      console.error("\u274C Failed to parse request body:", parseError);
      return {
        statusCode: 400,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*"
        },
        body: JSON.stringify({
          error: "Invalid request body - must be valid JSON",
          leads: [],
          count: 0
        })
      };
    }
    const { userId, scoutData, icpBrief } = requestBody;
    if (!scoutData) {
      console.error("\u274C No scoutData in request");
      return {
        statusCode: 400,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*"
        },
        body: JSON.stringify({
          error: "scoutData is required in request body",
          leads: [],
          count: 0
        })
      };
    }
    const apolloKey = process.env.APOLLO_API_KEY;
    if (!apolloKey) {
      console.error("\u274C APOLLO_API_KEY not set");
      return {
        statusCode: 500,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*"
        },
        body: JSON.stringify({
          error: "APOLLO_API_KEY not configured in Netlify environment variables",
          leads: [],
          count: 0
        })
      };
    }
    console.log("\u{1F4CA} Scout Data:", {
      industries: scoutData.industries?.length,
      jobTitles: scoutData.jobTitles?.length,
      companySizes: scoutData.companySizes?.length,
      locationScope: scoutData.locationScope,
      targetStates: scoutData.targetStates?.length,
      targetCities: scoutData.targetCities?.length
    });
    console.log("\u{1F3AF} ICP Brief:", icpBrief ? "Present" : "Not provided");
    const searchPayload = {
      page: 1,
      per_page: 25,
      person_locations: buildLocationArray(scoutData)
    };
    if (scoutData.jobTitles && scoutData.jobTitles.length > 0) {
      searchPayload.person_titles = scoutData.jobTitles.slice(0, 5);
    }
    if (scoutData.companySizes && scoutData.companySizes.length > 0) {
      const sizes = [];
      scoutData.companySizes.forEach((range) => {
        if (range.includes("1-10")) sizes.push("1-10");
        if (range.includes("11-50")) sizes.push("11-50");
        if (range.includes("51-200")) sizes.push("51-200");
        if (range.includes("201-500")) sizes.push("201-500");
        if (range.includes("501-1000")) sizes.push("501-1000");
        if (range.includes("1000+")) sizes.push("1001-10000");
      });
      if (sizes.length > 0) {
        searchPayload.organization_num_employees_ranges = sizes;
      }
    }
    console.log("\u{1F50D} Apollo Search Payload:", JSON.stringify(searchPayload, null, 2));
    const response = await fetch("https://api.apollo.io/v1/mixed_people/search", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Api-Key": apolloKey
      },
      body: JSON.stringify(searchPayload)
    });
    if (!response.ok) {
      const errorText = await response.text();
      console.error("\u274C Apollo API Error:", errorText);
      return {
        statusCode: 500,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*"
        },
        body: JSON.stringify({
          error: `Apollo API error: ${response.status}`,
          details: errorText,
          leads: [],
          count: 0
        })
      };
    }
    const apolloData = await response.json();
    console.log(`\u{1F4CA} Got ${apolloData.people?.length || 0} raw leads from Apollo`);
    if (!apolloData.people || apolloData.people.length === 0) {
      console.log("\u26A0\uFE0F No leads returned - search may be too narrow");
      return {
        statusCode: 200,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*"
        },
        body: JSON.stringify({
          leads: [],
          count: 0,
          message: "No leads found matching criteria. Try broadening your search."
        })
      };
    }
    const scoredLeads = (apolloData.people || []).map((person) => {
      const { score, breakdown, matchDetails } = calculateLeadScore(person, scoutData, icpBrief);
      return {
        id: person.id || Math.random().toString(36),
        name: person.name || "Unknown",
        title: person.title || "Unknown",
        company: person.organization?.name || "Unknown",
        industry: person.organization?.industry || "Unknown",
        employees: person.organization?.estimated_num_employees || 0,
        location: `${person.city || ""}${person.city && person.state ? ", " : ""}${person.state || ""}`.trim() || "Unknown",
        email: person.email || null,
        linkedin: person.linkedin_url || null,
        phone: person.phone_numbers?.[0]?.sanitized_number || null,
        photoUrl: person.photo_url || null,
        score,
        scoreBreakdown: breakdown,
        matchDetails,
        createdAt: (/* @__PURE__ */ new Date()).toISOString()
      };
    });
    scoredLeads.sort((a, b) => b.score - a.score);
    const topLeads = scoredLeads.slice(0, 10);
    console.log("\u{1F389} Returning top", topLeads.length, "scored leads");
    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
      },
      body: JSON.stringify({
        leads: topLeads,
        count: topLeads.length,
        scoreDistribution: {
          excellent: topLeads.filter((l) => l.score >= 85).length,
          good: topLeads.filter((l) => l.score >= 70 && l.score < 85).length,
          moderate: topLeads.filter((l) => l.score >= 50 && l.score < 70).length
        },
        generatedAt: (/* @__PURE__ */ new Date()).toISOString()
      })
    };
  } catch (error) {
    console.error("\u{1F4A5} CRITICAL ERROR:", error);
    return {
      statusCode: 500,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
      },
      body: JSON.stringify({
        error: error.message || "Unknown error occurred",
        errorType: error.name || "Error",
        leads: [],
        count: 0
      })
    };
  }
};
//# sourceMappingURL=generate-leads.js.map
